<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Home</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
 

  <meta name="HandheldFriendly" content="True" />
  <meta name="MobileOptimized" content="1024" />
  <meta name="viewport" content="width=1024, maximum-scale=1" />
  <meta id="meta-keywords" name="keywords" content=""/>
  <meta id="meta-description" name="description" content=""/>

  <link rel="stylesheet" type="text/css" href="/viewer/viewer.css"/>
<script type='text/javascript'>
var PageData = {"baseAddress":"http://yskexclusive.com","ServicesBasePath":"//admin.wzukltd.com","isTablet":false,"siteSettings":{"blogRssSettings":{"enabled":true},"behanceSocialLinkId":"{\"type\":\"behance\",\"title\":\"Behance\",\"url\":\"http://www.behance.com\"}","dribbbleSocialLinkId":"{\"type\":\"dribbble\",\"title\":\"Dribbble\",\"url\":\"http://www.dribbble.com\"}","enableColumnsGrid":"true","etsySocialLinkId":"{\"type\":\"etsy\",\"title\":\"Etsy\",\"url\":\"http://www.etsy.com\"}","facebookSocialLinkId":"{\"type\":\"facebook\",\"title\":\"Facebook\",\"url\":\"https://www.facebook.com/HostGator/\"}","flickrSocialLinkId":"{\"type\":\"flickr\",\"title\":\"Flickr\",\"url\":\"http://www.flickr.com\"}","googlePlusSocialLinkId":"{\"type\":\"googlePlus\",\"title\":\"Google+\",\"url\":\"http://plus.google.com/104217034959046240474\"}","instagramSocialLinkId":"{\"type\":\"instagram\",\"title\":\"Instagram\",\"url\":\"http://www.instagram.com\"}","isFirstMobileUse":"true","isFirstPreview":"true","linkedinSocialLinkId":"{\"type\":\"linkedin\",\"title\":\"LinkedIn\",\"url\":\"http://www.linkedin.com\"}","mobileIsDeactivated":"false","picasaSocialLinkId":"{\"type\":\"picasa\",\"title\":\"Picasa\",\"url\":\"http://www.picasa.com\"}","pinterestSocialLinkId":"{\"type\":\"pinterest\",\"title\":\"Pinterest\",\"url\":\"http://www.pinterest.com\"}","redditSocialLinkId":"{\"type\":\"reddit\",\"title\":\"Reddit\",\"url\":\"http://www.reddit.com\"}","renrenSocialLinkId":"{\"type\":\"renren\",\"title\":\"Renren\",\"url\":\"http://www.renren.com\"}","showAlwaysColumnsGrid":"false","soundCloudSocialLinkId":"{\"type\":\"soundCloud\",\"title\":\"SoundCloud\",\"url\":\"http://www.soundcloud.com\"}","tripAdvisorSocialLinkId":"{\"type\":\"tripAdvisor\",\"title\":\"Trip Advisor\",\"url\":\"http://www.tripadvisor.com\"}","tumblrSocialLinkId":"{\"type\":\"tumblr\",\"title\":\"Tumblr\",\"url\":\"http://www.tumblr.com\"}","twitterSocialLinkId":"{\"type\":\"twitter\",\"title\":\"Twitter\",\"url\":\"https://twitter.com/hostgator\"}","vimeoSocialLinkId":"{\"type\":\"vimeo\",\"title\":\"Vimeo\",\"url\":\"http://www.vimeo.com\"}","vkSocialLinkId":"{\"type\":\"vk\",\"title\":\"VK\",\"url\":\"http://www.vk.com\"}","weiboSocialLinkId":"{\"type\":\"weibo\",\"title\":\"Weibo\",\"url\":\"http://www.weibo.com\"}","youtubeSocialLinkId":"{\"type\":\"youtube\",\"title\":\"Youtube\",\"url\":\"http://www.youtube.com\"}"},"defaultAjaxPageID":"id1343569893637","PageNotFound":false};
var Global = {"FacebookAppID":"310287139132389","IsMobile":false,"IsMobileView":false,"IsMobileClient":false,"SiteID":44200290,"IsNewStructure":true};

</script>
<script src='/viewer/viewer.js' type='text/javascript'></script>
<script src='https://storage.googleapis.com/wzukusers/user-25894872/sites/44200290/583b36d843457PhUiUVc/5843979ac5474z3D2ful.js?1480824733' type='text/javascript'></script>
<script src='https://storage.googleapis.com/wzukusers/user-25894872/sites/44200290/583b36d843457PhUiUVc/m1RTrG1f52jFqM4zjSE6.js?1480824733' type='text/javascript'></script>
<script src='https://storage.googleapis.com/wzukusers/user-25894872/sites/44200290/583b36d843457PhUiUVc/vvxroJsV5vhVNOpwTwHu.js?1480824733' type='text/javascript'></script>
<script type='text/javascript'>
var SiteFilesMap = {"page-id1343569893637":"https://storage.googleapis.com/wzukusers/user-25894872/sites/44200290/583b36d843457PhUiUVc/vvxroJsV5vhVNOpwTwHu.js","page-1407392660905":"https://storage.googleapis.com/wzukusers/user-25894872/sites/44200290/583b36d843457PhUiUVc/xj8U4NROdFmFYd4ZoWvf.js","page-1407392663242":"https://storage.googleapis.com/wzukusers/user-25894872/sites/44200290/583b36d843457PhUiUVc/vCoGGqT3y2Q4xovW8XRd.js","page-1407410380611":"https://storage.googleapis.com/wzukusers/user-25894872/sites/44200290/583b36d843457PhUiUVc/s99gXyMR4ulz6KfMb8PJ.js","page-1407392665523":"https://storage.googleapis.com/wzukusers/user-25894872/sites/44200290/583b36d843457PhUiUVc/Aoto9xO4NGpwtcQjziDq.js","master-1343569893636":"https://storage.googleapis.com/wzukusers/user-25894872/sites/44200290/583b36d843457PhUiUVc/m1RTrG1f52jFqM4zjSE6.js","site-structure":"https://storage.googleapis.com/wzukusers/user-25894872/sites/44200290/583b36d843457PhUiUVc/5843979ac5474z3D2ful.js"};</script>

  <script type="text/javascript">
    var DynamicPageContent = null;
    var DBSiteMetaData = {
      'pagesStructureInformation':{
        'pagesData':{"id1343569893637":{"metaTags":"","tags":[],"id":"id1343569893637","title":"Home","index":1,"pageTitle":"","keyWords":"","description":"","shareStyle":true,"useNameASTitle":false,"isHomePage":true,"supportsMobileStates":true,"urlAlias":"","useNameASUrl":false},"1407392660905":{"metaTags":"","tags":[],"id":"1407392660905","title":"Shop","pageTitle":"Our Products","description":"","keyWords":"","index":2,"isHomePage":false,"shareStyle":true,"useNameASTitle":false,"supportsMobileStates":true,"urlAlias":"shop","useNameASUrl":true},"1407392663242":{"metaTags":"","tags":[],"id":"1407392663242","title":"LookBook","pageTitle":"LookBook","description":"","keyWords":"","index":3,"isHomePage":false,"shareStyle":true,"useNameASTitle":false,"supportsMobileStates":true,"urlAlias":"lookbook","useNameASUrl":true,"useDefaultTitle":false},"1407410380611":{"metaTags":"","tags":[],"id":"1407410380611","title":"Art","pageTitle":"Art","description":"","keyWords":"","index":4,"isHomePage":false,"useNameASTitle":true,"shareStyle":true,"supportsMobileStates":true,"urlAlias":"art","useNameASUrl":true,"useDefaultTitle":false},"1407392665523":{"metaTags":"","tags":[],"id":"1407392665523","title":"About Us","pageTitle":"Contact Us","description":"","keyWords":"","index":5,"isHomePage":false,"shareStyle":true,"useNameASTitle":false,"supportsMobileStates":true,"urlAlias":"about-us","useNameASUrl":true}},
        'pagesHierarchies':{}      },
      'siteStructureInformation':{
        'masterPages': {"1343569893636":{"pagesIDs":["id1343569893637","1407392660905","1407392663242","1407410380611","1407392665523"]}},
        'listsInformation':{}      }
    };

    var TemporaryImages = {"61921892":{"id":61921892,"imagePath":"58421a873dd57M4DN2K2\/Hearts.jpg","thumbPath":"","imageWidth":549,"imageHeight":281,"title":"Hearts","description":"","category":100,"storageServer":6,"ownerID":25894872,"albumID":null,"scaledVersions":[{"size":200,"suffix":"_d200"},{"size":400,"suffix":"_d400"}],"isTemporary":0}}
    Viewer.initialize();
  </script>
    <?php wp_head();?>

</head>